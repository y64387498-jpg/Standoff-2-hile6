# Standoff 2 ESP Demo (Android)

Bu proje, yalnızca ekran üzerinde örnek bir ESP kutusu çizen görsel bir demodur.
Gerçek oyuncu konumlarını algılamaz; Standoff 2 belleğine, ağına veya oyun dosyalarına
erişmez ve oyuna müdahale etmez.

## Android Studio ile APK oluşturma
1. ZIP dosyasını çıkar.
2. Android Studio'da `Standoff2_ESP_Demo` klasörünü aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
5. Oluşan APK'yı telefona yükle.

## Kullanım
1. Uygulamayı açıp **BAŞLAT** düğmesine bas.
2. Android ayarlarında "Diğer uygulamaların üzerinde göster" iznini etkinleştir.
3. Uygulamaya dönüp **BAŞLAT** düğmesine yeniden bas.
4. Demo paneli görünür ve Standoff 2 yüklüyse oyun açılır.
5. Paneli sürükleyerek taşıyabilirsin. Paneli kapatmak için uygulamayı son uygulamalardan kapat.

Not: Bu kaynak proje Android Studio içindir; hazır APK değildir.
