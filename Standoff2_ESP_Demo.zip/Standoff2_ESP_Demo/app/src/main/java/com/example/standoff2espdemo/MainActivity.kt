package com.example.standoff2espdemo

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val gamePackage = "com.axlebolt.standoff2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "STANDOFF 2  •  ESP DEMO"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Bu uygulama yalnızca görsel bir ESP simülasyonu gösterir. Oyuncuları algılamaz ve oyuna müdahale etmez."
            textSize = 14f
            setTextColor(0xFFCFD8DC.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(12, 24, 12, 28)
        }
        val start = Button(this).apply {
            text = "BAŞLAT"
            textSize = 20f
            setOnClickListener { startDemo() }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(start, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 64
        ))
        setContentView(layout)
    }

    private fun startDemo() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Diğer uygulamaların üzerinde gösterme iznini aç, sonra BAŞLAT'a tekrar bas.", Toast.LENGTH_LONG).show()
            return
        }

        startService(Intent(this, EspOverlayService::class.java))

        val launchIntent = packageManager.getLaunchIntentForPackage(gamePackage)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Standoff 2 bulunamadı. Demo paneli açıldı.", Toast.LENGTH_LONG).show()
        }
    }
}
